#include "connection.h"
Connection::Connection(){
	weight=randomWeight();
	deltaWeight=0;
}

