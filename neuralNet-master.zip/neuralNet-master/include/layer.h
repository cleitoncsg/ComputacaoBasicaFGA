#include <vector>
#include "neuron.h"

using namespace std;

class Neuron;

typedef vector<Neuron> Layer;