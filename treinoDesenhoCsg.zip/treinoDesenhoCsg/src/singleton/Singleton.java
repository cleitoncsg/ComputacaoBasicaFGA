package singleton;

public class Singleton {

	Singleton instancia = null;
	
	public Singleton() {
		
	}
	
	public Singleton get_Instancia (){
		
		
		if(instancia == null){
			return instancia;
		}
		else
			instancia = new Singleton();
		
		return instancia;
	}

}
