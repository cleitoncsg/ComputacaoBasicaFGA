package metodoFabricaConcertado;

public class Especial extends Aluno{

	public Especial() {
		// TODO Auto-generated constructor stub
	}

}
