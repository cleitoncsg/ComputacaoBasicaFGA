package metodoFabrica;


public class Graduacao extends Aluno{

	
	protected int anoEntrada;
	protected String curso;
	
	
	public Graduacao() {
		// TODO Auto-generated constructor stub
	}

}
