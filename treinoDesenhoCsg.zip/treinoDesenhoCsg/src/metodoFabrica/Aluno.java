package metodoFabrica;

public class Aluno {

	private String nome;
	private int matricula;
	
	
	public Aluno() {
		// TODO Auto-generated constructor stub
	}

}
