package metodoFabrica;


public class PosGraduacao extends Aluno {

	protected String projeto, nivel;
	
	public PosGraduacao() {
		// TODO Auto-generated constructor stub
	}

}
